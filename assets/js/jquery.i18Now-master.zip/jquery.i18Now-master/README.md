jquery.i18Now
=============

This plugin is intended to help client-side formatting of date and time according to the user preferences or the most used format in a specific country.

Check out examples/ content for demo
